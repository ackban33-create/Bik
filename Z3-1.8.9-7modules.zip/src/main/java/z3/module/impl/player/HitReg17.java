package z3.module.impl.player;
import z3.mixin.impl.accessor.IAccessorMinecraft;
import z3.module.Module;
import z3.module.setting.impl.ButtonSetting;
import z3.utility.Utils;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
public class HitReg17 extends Module {
 public ButtonSetting oldReg;
 public HitReg17(){super("1.7 hitreg",category.player,0);registerSetting(oldReg=new ButtonSetting("Enabled",true));}
 @SubscribeEvent public void onTick(TickEvent.PlayerTickEvent e){if(e.phase!=TickEvent.Phase.END||!mc.inGameHasFocus||!Utils.nullCheck())return;if(oldReg.isToggled())((IAccessorMinecraft)mc).setLeftClickCounter(0);}
}
