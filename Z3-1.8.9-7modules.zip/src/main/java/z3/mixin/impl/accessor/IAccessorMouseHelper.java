package z3.mixin.impl.accessor; public interface IAccessorMouseHelper { int getDeltaX(); int getDeltaY(); }
