package z3.mixin.impl.accessor; public interface IAccessorMinecraft { void setLeftClickCounter(int v); }
