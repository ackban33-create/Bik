plugins {
    java
    idea
    id("gg.essential.loom") version "0.10.0.5"
    id("dev.architectury.architectury-pack200") version "0.1.3"
    id("com.github.johnrengelman.shadow") version "8.1.1"
}
java { toolchain.languageVersion.set(JavaLanguageVersion.of(8)) }
loom {
    forge { pack200Provider.set(dev.architectury.pack200.java.Pack200Adapter()); mixinConfig("mixins.z3.json") }
    launchConfigs { "client" { property("mixin.debug", "true"); arg("--tweakClass", "org.spongepowered.asm.launch.MixinTweaker") } }
    runConfigs { "client" { }; remove(getByName("server")) }
    mixin { defaultRefmapName.set("mixins.z3.refmap.json") }
}
repositories { mavenCentral(); maven("https://repo.polyfrost.cc/releases/") }
val shadowImpl: Configuration by configurations.creating { configurations.implementation.get().extendsFrom(this) }
dependencies {
    minecraft("com.mojang:minecraft:1.8.9")
    mappings("de.oceanlabs.mcp:mcp_stable:22-1.8.9")
    forge("net.minecraftforge:forge:1.8.9-11.15.1.2318-1.8.9")
    shadowImpl("org.spongepowered:mixin:0.7.11-SNAPSHOT") { isTransitive=false; exclude(module="gson"); exclude(module="guava"); exclude(module="jarjar"); exclude(module="commons-codec"); exclude(module="commons-io"); exclude(module="launchwrapper"); exclude(module="asm-commons"); exclude(module="slf4j-api") }
    annotationProcessor("org.spongepowered:mixin:0.8.5-SNAPSHOT")
}
tasks.withType<JavaCompile> { options.encoding="UTF-8" }
tasks.withType<Jar> { archiveBaseName.set("z3"); manifest.attributes["FMLCorePluginContainsFMLMod"]="true"; manifest.attributes["ForceLoadAsMod"]="true"; manifest.attributes["TweakClass"]="org.spongepowered.asm.launch.MixinTweaker"; manifest.attributes["MixinConfigs"]="mixins.z3.json" }
tasks.processResources { inputs.property("version", project.version); filesMatching(listOf("mcmod.info","mixins.z3.json")) { expand(inputs.properties) } }
tasks.jar { archiveClassifier.set("without-deps"); destinationDirectory.set(layout.buildDirectory.dir("intermediates")) }
tasks.shadowJar { destinationDirectory.set(layout.buildDirectory.dir("intermediates")); archiveClassifier.set("non-obfuscated-with-deps"); configurations=listOf(shadowImpl); exclude("META-INF/**"); exclude("org/**/*.html"); exclude("org/lwjgl/**"); }
val remapJar by tasks.named<net.fabricmc.loom.task.RemapJarTask>("remapJar") { archiveClassifier.set(""); from(tasks.shadowJar); input.set(tasks.shadowJar.get().archiveFile) }
tasks.assemble.get().dependsOn(remapJar)
