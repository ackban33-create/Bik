pluginManagement { repositories { gradlePluginPortal(); maven("https://maven.minecraftforge.net/"); maven("https://repo.polyfrost.cc/releases/") } }
dependencyResolutionManagement { repositories { mavenCentral(); maven("https://maven.minecraftforge.net/"); maven("https://repo.polyfrost.cc/releases/") } }
rootProject.name = "Z3-1.8.9"
