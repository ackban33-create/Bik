# Z3 — Forge 1.8.9

Only seven modules are included: Block Overlay, Free Look, Hit Particles, Item Physics, TNT Timer, 1.7 hitreg, NoHurtCam.

Right Shift opens the GUI. `S` saves `Default.json`, `L` loads it.
