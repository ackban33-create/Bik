# Building in GitHub Codespaces

This project is configured for **JDK 17** and **Gradle 8.8**.

## Codespaces

Open the repository in GitHub Codespaces and rebuild the container when prompted.
The devcontainer installs Java 17 and Gradle 8.8 automatically.

Then run:

```bash
./gradlew build
```

The `gradle-wrapper.properties` file is pinned to Gradle 8.8. If the binary
`gradle-wrapper.jar` is not present in a source archive, `./gradlew` falls back
to the installed Gradle 8.8 CLI in Codespaces instead of failing with
`GradleWrapperMain`.

## Important

The Gradle installation is a **build-time dependency**. It is not application
runtime code and does not add an HTTP/WebSocket client to the mod itself.
