package keystrokesmod.utility;

import keystrokesmod.Raven;
import keystrokesmod.helper.PingHelper;
import keystrokesmod.module.Module;
import keystrokesmod.utility.profile.Profile;
import net.minecraft.client.gui.FontRenderer;
import org.lwjgl.opengl.GL11;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CommandHandler implements IMinecraftInstance {
    private static final int GL_SCISSOR_TEST = 3089;
    private static final int COMMAND_PANEL_X_OFFSET = 195;
    private static final int COMMAND_PANEL_Y_OFFSET = 130;
    private static final int COMMAND_PANEL_START_Y = 345;
    private static final int COMMAND_PANEL_HEIGHT = 230;
    private static final int MIN_SCISSOR_WIDTH = 2;

    private static boolean hasShownWelcome = true;
    private static final List<Integer> backgroundColors = Arrays.asList(
        new Color(170, 107, 148, 50).getRGB(),
        new Color(122, 158, 134, 50).getRGB(),
        new Color(16, 16, 16, 50).getRGB(),
        new Color(64, 114, 148, 50).getRGB()
    );
    private static int currentBackgroundColor;
    private static int lastBackgroundColorIndex = -1;
    public static List<String> responseLines = new ArrayList<>();

    public static void runCommand(String contents) {
        if (contents == null || contents.trim().isEmpty()) return;
        String[] args = contents.trim().split("\\s+");
        String command = args[0].toLowerCase();
        switch (command) {
            case "ping":
                PingHelper.checkPing(false);
                break;
            case "clear":
                responseLines.clear();
                break;
            case "hide":
                setHidden(args, true);
                break;
            case "show":
                setHidden(args, false);
                break;
            case "friend":
            case "f":
                handleRelation(args, true);
                break;
            case "enemy":
            case "e":
                handleRelation(args, false);
                break;
            case "debug":
                Raven.DEBUG = !Raven.DEBUG;
                print("Debug " + (Raven.DEBUG ? "enabled" : "disabled") + ".", 1);
                break;
            case "profiles":
            case "p":
                handleProfiles(args);
                break;
            case "help":
            case "?":
                print("&eAvailable commands:", 1);
                print("1 friend/enemy [name/clear]", 0);
                print("2 ping", 0);
                print("3 hide/show [module]", 0);
                print("&eProfiles:", 0);
                print("1 profiles", 0);
                print("2 profiles save [profile]", 0);
                print("3 profiles load [profile]", 0);
                print("4 profiles remove [profile]", 0);
                break;
            default:
                String preview = command.length() > 5 ? command.substring(0, 5) + "..." : command;
                print("&cInvalid command. (" + preview + ")", 1);
        }
    }

    private static void setHidden(String[] args, boolean hidden) {
        if (args.length != 2) {
            print("&cInvalid syntax.", 1);
            return;
        }
        for (Module module : Raven.getModuleManager().getModules()) {
            if (module.getName().replace(" ", "").equalsIgnoreCase(args[1])) {
                module.setHidden(hidden);
                print("&a" + module.getName() + (hidden ? " is now hidden" : " is now visible"), 1);
                return;
            }
        }
        print("&cModule not found.", 1);
    }

    private static void handleRelation(String[] args, boolean friend) {
        if (args.length != 2) {
            print("&cInvalid syntax.", 1);
            return;
        }
        if ("clear".equalsIgnoreCase(args[1])) {
            if (friend) Raven.playerRelationsManager.clearFriends();
            else Raven.playerRelationsManager.clearEnemies();
            print("&aCleared.", 1);
            return;
        }
        boolean added = friend ? Utils.addFriend(args[1]) : Utils.addEnemy(args[1]);
        if (added) print("&aAdded: " + args[1], 1);
        else {
            if (friend) Utils.removeFriend(args[1]); else Utils.removeEnemy(args[1]);
            print("&aRemoved: " + args[1], 1);
        }
    }

    private static void handleProfiles(String[] args) {
        if (args.length == 1) {
            print("&aAvailable profiles:", 1);
            if (Raven.profileManager.profiles.isEmpty()) { print("None", 0); return; }
            for (int i = 0; i < Raven.profileManager.profiles.size(); i++) print((i + 1) + ". " + Raven.profileManager.profiles.get(i).getName(), 0);
            return;
        }
        if (args.length != 3) { print("&cInvalid syntax.", 1); return; }
        String name = args[2];
        switch (args[1].toLowerCase()) {
            case "save":
            case "s":
                if (name.length() < 2 || name.length() > 10) { print("&cInvalid name.", 1); return; }
                Raven.profileManager.saveProfile(new Profile(name, 0));
                Raven.profileManager.loadProfiles();
                print("&aSaved profile: " + name, 1);
                break;
            case "load":
            case "l":
                for (Profile profile : Raven.profileManager.profiles) if (profile.getName().equals(name)) {
                    Raven.profileManager.loadProfile(name);
                    print("&aLoaded profile: " + name, 1);
                    return;
                }
                print("&cInvalid profile.", 1);
                break;
            case "remove":
            case "r":
                for (Profile profile : Raven.profileManager.profiles) if (profile.getName().equals(name)) {
                    Raven.profileManager.deleteProfile(name);
                    Raven.profileManager.loadProfiles();
                    print("&aRemoved profile: " + name, 1);
                    return;
                }
                print("&cInvalid profile.", 1);
                break;
            default:
                print("&cInvalid syntax.", 1);
        }
    }

    public static void print(String message, int type) {
        if (type == 1 || type == 2) responseLines.add("");
        responseLines.add(message);
        if (type == 2 || type == 3) responseLines.add("");
    }

    public static void renderCommandOutput(FontRenderer fontRenderer, int height, int width, double scale) {
        int x = width - COMMAND_PANEL_X_OFFSET;
        int y = height - COMMAND_PANEL_Y_OFFSET;
        int startY = height - COMMAND_PANEL_START_Y;
        int panelHeight = COMMAND_PANEL_HEIGHT;
        GL11.glEnable(GL_SCISSOR_TEST);
        double maxWidth = width * scale;
        int scissorWidth = (int) (maxWidth - (maxWidth < MIN_SCISSOR_WIDTH ? 0 : MIN_SCISSOR_WIDTH));
        int scissorHeight = (int) (panelHeight * scale - MIN_SCISSOR_WIDTH);
        int scissorY = (int) (mc.displayHeight - (startY + panelHeight) * scale);
        GL11.glScissor(0, scissorY, scissorWidth, scissorHeight);
        RenderUtils.db(1000, 1000, currentBackgroundColor);
        renderResponseStrings(fontRenderer, responseLines, x, y);
        GL11.glDisable(GL_SCISSOR_TEST);
    }

    private static void renderResponseStrings(FontRenderer fontRenderer, List<String> lines, int x, int y) {
        if (hasShownWelcome) {
            hasShownWelcome = false;
            print("Welcome,", 0);
            print("Use \"help\" for help.", 0);
        }
        for (int i = lines.size() - 1; i >= 0; --i) {
            String line = lines.get(i);
            int color = -1;
            if (line.contains("&a")) { line = line.replace("&a", ""); color = Color.green.getRGB(); }
            else if (line.contains("&c")) { line = line.replace("&c", ""); color = Color.red.getRGB(); }
            else if (line.contains("&e")) { line = line.replace("&e", ""); color = Color.yellow.getRGB(); }
            fontRenderer.drawString(line, x, y, color);
            y -= fontRenderer.FONT_HEIGHT + 5;
        }
    }

    public static void setBackgroundColor() {
        int randomIndex = Utils.getRandom().nextInt(backgroundColors.size());
        if (randomIndex == lastBackgroundColorIndex) randomIndex = randomIndex == 3 ? 0 : randomIndex + 1;
        lastBackgroundColorIndex = randomIndex;
        currentBackgroundColor = backgroundColors.get(randomIndex);
    }

    public static void onDisable() {
        responseLines.clear();
    }
}
