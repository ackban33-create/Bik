package keystrokesmod.utility.system;

import keystrokesmod.utility.Utils;

import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.math.BigInteger;
import java.security.MessageDigest;

public class SystemUtils {
    public static void addToClipboard(String string) {
        try {
            Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
            StringSelection stringSelection = new StringSelection(string);
            clipboard.setContents(stringSelection, null);
        }
        catch (Exception e) {
            Utils.sendMessage("&cFailed to copy &b" + string);
        }
    }
}