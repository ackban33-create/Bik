package keystrokesmod.command.impl;

import keystrokesmod.command.Command;
import keystrokesmod.command.CommandInput;

public class Cname extends Command {
    public Cname() {
        super("namehider");
    }

    @Override
    public void execute(CommandInput input) {
        replyWithHeader("&cName Hider has been removed from this build.");
    }
}
