package keystrokesmod.mixin.impl.render;

import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.spongepowered.asm.mixin.Mixin;
import net.minecraft.client.gui.FontRenderer;

@SideOnly(Side.CLIENT)
@Mixin(FontRenderer.class)
public class MixinFontRenderer {
}
