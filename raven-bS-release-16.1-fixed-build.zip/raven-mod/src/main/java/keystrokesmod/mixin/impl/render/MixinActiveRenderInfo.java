package keystrokesmod.mixin.impl.render;

import net.minecraft.client.renderer.ActiveRenderInfo;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.spongepowered.asm.mixin.Mixin;

@SideOnly(Side.CLIENT)
@Mixin(ActiveRenderInfo.class)
public class MixinActiveRenderInfo {
}
