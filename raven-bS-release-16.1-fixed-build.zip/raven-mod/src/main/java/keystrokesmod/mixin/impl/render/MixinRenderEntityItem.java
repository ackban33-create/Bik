package keystrokesmod.mixin.impl.render;

import net.minecraft.client.renderer.entity.RenderEntityItem;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.spongepowered.asm.mixin.Mixin;

@SideOnly(Side.CLIENT)
@Mixin(RenderEntityItem.class)
public class MixinRenderEntityItem {
}
