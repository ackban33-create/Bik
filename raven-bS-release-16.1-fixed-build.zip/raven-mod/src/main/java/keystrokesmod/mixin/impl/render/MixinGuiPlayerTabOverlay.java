package keystrokesmod.mixin.impl.render;

import net.minecraft.client.gui.GuiPlayerTabOverlay;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.spongepowered.asm.mixin.Mixin;

@SideOnly(Side.CLIENT)
@Mixin(GuiPlayerTabOverlay.class)
public class MixinGuiPlayerTabOverlay {

}
