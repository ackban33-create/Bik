package keystrokesmod.module;

import keystrokesmod.module.impl.client.ChatCommands;
import keystrokesmod.module.impl.client.CommandLine;
import keystrokesmod.module.impl.client.Gui;
import keystrokesmod.module.impl.client.Relationships;
import keystrokesmod.module.impl.client.Settings;
import keystrokesmod.module.impl.combat.*;
import keystrokesmod.module.impl.movement.*;
import keystrokesmod.module.impl.player.*;
import keystrokesmod.module.impl.render.*;
import keystrokesmod.module.impl.world.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ModuleManager {
    public static List<Module> modules = new ArrayList<>();
    public static List<Module> organizedModules = Collections.synchronizedList(new ArrayList<>());
    private static final Map<String, Module> modulesByName = new HashMap<>();
    private static final Map<String, Module> modulesByNormalizedName = new HashMap<>();
    private static final Map<Class<?>, Module> modulesByClass = new HashMap<>();

    // Kept only for core/mixin compatibility and the selected modules.
    public static AntiFireball antiFireball;
    public static AutoClicker autoClicker;
    public static AutoTool autoTool;
    public static Blink blink;
    public static Chams chams;
    public static HitSelect hitSelect;
    public static KeepSprint keepSprint;
    public static MovementFix movementFix;
    public static PlayerESP playerESP;
    public static Reach reach;
    public static SafeWalk safeWalk;
    public static Sprint sprint;
    public static WTap wTap;
    public static AntiBot antiBot;
    public static Weather weather;
    public static FastPlace fastPlace;
    public static ChatCommands chatCommands;
    public static CommandLine commandLine;
    public static Relationships relationships;
    public static Gui gui;
    public static Settings settings;

    public void register() {
        // Client infrastructure (not gameplay feature modules).
        this.addModule(chatCommands = new ChatCommands());
        this.addModule(commandLine = new CommandLine());
        this.addModule(gui = new Gui());
        this.addModule(settings = new Settings());
        this.addModule(relationships = new Relationships());

        // Combat: requested modules only.
        this.addModule(new AimAssist());
        this.addModule(autoClicker = new AutoClicker());
        this.addModule(new Autoblock());
        this.addModule(new Displace());
        this.addModule(hitSelect = new HitSelect());
        this.addModule(new HitBox());
        this.addModule(new JumpReset());
        this.addModule(new LagRange());
        this.addModule(reach = new Reach());
        this.addModule(new RodAimbot());
        this.addModule(wTap = new WTap());

        // Movement: requested modules only.
        this.addModule(keepSprint = new KeepSprint());
        this.addModule(movementFix = new MovementFix());
        this.addModule(sprint = new Sprint());

        // Player: requested modules only.
        this.addModule(antiFireball = new AntiFireball());
        this.addModule(autoTool = new AutoTool());
        this.addModule(blink = new Blink());
        this.addModule(new BlockIn());
        this.addModule(new BridgeAssist());
        this.addModule(new Clutch());
        this.addModule(new DelayRemover());
        this.addModule(new FakeLag());
        this.addModule(fastPlace = new FastPlace());
        this.addModule(safeWalk = new SafeWalk());

        // Render: requested modules only.
        this.addModule(chams = new Chams());
        this.addModule(new Nametags());
        this.addModule(playerESP = new PlayerESP());

        // World: both modules.
        this.addModule(antiBot = new AntiBot());
        this.addModule(weather = new Weather());

        movementFix.enable();
        antiBot.enable();
        modules.sort(Comparator.comparing(Module::getName));
    }

    public void addModule(Module module) {
        modules.add(module);
        modulesByName.put(module.getName(), module);
        modulesByNormalizedName.put(normalizeModuleName(module.getName()), module);
        modulesByClass.put(module.getClass(), module);
    }

    public List<Module> getModules() {
        return modules;
    }

    public List<Module> inCategory(Module.category category) {
        ArrayList<Module> categoryModules = new ArrayList<>();

        for (Module module : this.getModules()) {
            if (module.moduleCategory().equals(category)) {
                categoryModules.add(module);
            }
        }

        return categoryModules;
    }

    public static Module getModule(String moduleName) {
        Module module = modulesByName.get(moduleName);
        if (module != null) {
            return module;
        }
        return modulesByNormalizedName.get(normalizeModuleName(moduleName));
    }

    public static Module getModule(Class<?> clazz) {
        return modulesByClass.get(clazz);
    }

    public static void sort() {
        organizedModules.sort(Comparator.comparing(Module::getNameInHud));
    }

    private static String normalizeModuleName(String moduleName) {
        if (moduleName == null) {
            return "";
        }

        StringBuilder normalized = new StringBuilder(moduleName.length());
        for (int i = 0; i < moduleName.length(); i++) {
            char character = moduleName.charAt(i);
            if (Character.isLetterOrDigit(character)) {
                normalized.append(Character.toLowerCase(character));
            }
        }
        return normalized.toString();
    }
}
