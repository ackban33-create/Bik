#!/usr/bin/env bash
set -e

echo "=== Java ==="
java -version

echo "=== Gradle ==="
gradle --version

echo "=== Project wrapper configuration ==="
grep '^distributionUrl=' gradle/wrapper/gradle-wrapper.properties

echo
echo "Codespaces build environment is ready."
echo "Use: ./gradlew build"
