package lockin.client.gui;

import lockin.client.config.ConfigManager;
import lockin.client.module.Module;
import lockin.client.module.ModuleManager;
import lockin.client.module.setting.Setting;
import lockin.client.module.setting.impl.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import org.lwjgl.input.Keyboard;
import java.awt.*;

public class LockInGui extends GuiScreen {
    private final ModuleManager manager = Minecraft.getMinecraft().thePlayer == null ? null : lockin.client.LockInClient.INSTANCE.getModuleManager();
    private Module selected;
    private int scroll;
    private long toastUntil;
    private String toast="";
    private String search="";

    @Override public void initGui(){super.initGui(); if(selected==null&&!manager.getModules().isEmpty())selected=manager.getModules().get(0);}
    private int bg(int a){return new Color(10,10,16,a).getRGB();}
    private int purple(int a){return new Color(145,80,255,a).getRGB();}
    @Override public void drawScreen(int mx,int my,float pt){
        drawRect(0,0,width,height,new Color(5,5,10,240).getRGB());
        drawGradientRect(0,0,width,height,new Color(10,8,20,255).getRGB(),new Color(18,8,28,255).getRGB());
        int left=24, top=20, side=220;
        drawRect(left,top,left+side,height-20,new Color(18,18,28,245).getRGB());
        drawString(fontRendererObj,"LOCK IN",left+18,top+17,0xffd8c4ff);
        drawString(fontRendererObj,"CLIENT  •  1.8.9",left+18,top+33,0xff77738a);
        drawRect(left+16,top+51,left+side-16,top+52,purple(220));
        drawString(fontRendererObj,"MODULES",left+18,top+66,0xff9892a8);
        int y=top+86;
        for(Module m:manager.getModules()){
            if(!search.isEmpty()&&!m.getName().toLowerCase().contains(search.toLowerCase()))continue;
            boolean sel=m==selected;
            if(sel)drawRect(left+12,y-4,left+side-12,y+20,new Color(145,80,255,55).getRGB());
            drawString(fontRendererObj,m.getName(),left+22,y+3,sel?0xffeee5ff:0xffc5c0cf);
            drawString(fontRendererObj,m.isEnabled()?"ON":"OFF",left+side-55,y+3,m.isEnabled()?0xffc89cff:0xff6d6878);
            y+=28;
        }
        int x=left+side+18, right=width-24;
        drawRect(x,top,x+8,top+8,purple(255));
        drawString(fontRendererObj,selected==null?"Modules":selected.getName(),x+16,top,0xfff0eaff);
        drawString(fontRendererObj,"F1  •  RSHIFT toggles GUI",x+16,top+17,0xff77738a);
        if(selected!=null){
            int sy=top+52-scroll;
            drawRect(x,sy-8,right,sy-7,new Color(55,50,65,255).getRGB());
            for(Setting s:selected.getSettings()){
                if(!s.isVisible())continue;
                sy=drawSetting(s,x,sy,right,mx,my);
                sy+=12;
            }
            int footer=height-42;
            drawRect(x,footer,right,footer+1,new Color(60,55,72,255).getRGB());
            button(x,footer+10,x+92,footer+31,"SAVE",0xffa66dff);
            button(x+102,footer+10,x+194,footer+31,"LOAD",0xff6e6a7c);
            button(right-108,footer+10,right,footer+31,"RESET",0xff6e6a7c);
        }
        if(System.currentTimeMillis()<toastUntil){drawRect(width/2-110,height-64,width/2+110,height-40,new Color(23,19,34,245).getRGB());drawCenteredString(fontRendererObj,toast,width/2,height-56,0xffd7beff);}
        super.drawScreen(mx,my,pt);
    }
    private int drawSetting(Setting s,int x,int y,int right,int mx,int my){
        drawString(fontRendererObj,s.getName(),x,y,0xffcbc6d5);
        if(s instanceof DescriptionSetting){return y+16;}
        if(s instanceof ButtonSetting){ButtonSetting b=(ButtonSetting)s; button(right-80,y-4,right,y+16,b.isToggled()?"ON":"OFF",b.isToggled()?0xff9d62ff:0xff3e3a47);}
        else if(s instanceof SliderSetting){SliderSetting sl=(SliderSetting)s;double pct=(sl.getInput()-sl.getMin())/Math.max(0.0001,sl.getMax()-sl.getMin());drawRect(right-180,y+11,right,y+13,new Color(55,50,65,255).getRGB());drawRect(right-180,y+11,right-180+(int)(180*pct),y+13,purple(255));String val=sl.isString&&sl.getOptions()!=null?sl.getOptions()[(int)sl.getInput()]:String.format("%.2f",sl.getInput());drawString(fontRendererObj,val,right-58,y,0xffb792ff);}
        else if(s instanceof KeySetting){KeySetting k=(KeySetting)s;drawString(fontRendererObj,Keyboard.getKeyName(k.getKey()),right-76,y,0xffb792ff);}
        else if(s instanceof ColorSetting){ColorSetting c=(ColorSetting)s;drawRect(right-34,y,right,y+12,c.getColor());}
        return y+27;
    }
    private void button(int x1,int y1,int x2,int y2,String text,int accent){drawRect(x1,y1,x2,y2,new Color(30,27,39,255).getRGB());if(accent!=0)drawRect(x1,y1,x2,y1+2,accent);drawCenteredString(fontRendererObj,text,(x1+x2)/2,y1+6,0xffd8d3e2);}
    @Override protected void mouseClicked(int mx,int my,int btn) throws java.io.IOException{
        if(btn!=0)return;
        int left=24, top=20, side=220, y=top+86;
        for(Module m:manager.getModules()){
            if(!search.isEmpty()&&!m.getName().toLowerCase().contains(search.toLowerCase()))continue;
            if(mx>=left+12&&mx<=left+side-12&&my>=y-4&&my<=y+20){selected=m;return;} y+=28;
        }
        int x=left+side+18,right=width-24,sy=top+52-scroll;
        if(selected!=null){for(Setting s:selected.getSettings()){if(!s.isVisible())continue;if(s instanceof ButtonSetting&&mx>=right-80&&mx<=right&&my>=sy-4&&my<=sy+16){((ButtonSetting)s).toggle();ConfigManager.markDirty();return;}if(s instanceof SliderSetting&&mx>=right-180&&mx<=right&&my>=sy&&my<=sy+18){SliderSetting sl=(SliderSetting)s;double pct=Math.max(0,Math.min(1,(mx-(right-180))/180.0));sl.setValue(sl.getMin()+pct*(sl.getMax()-sl.getMin()));ConfigManager.markDirty();return;}sy+=((s instanceof DescriptionSetting)?16:27)+12;}
            int footer=height-42;if(my>=footer+10&&my<=footer+31){if(mx>=x&&mx<=x+92){ConfigManager.save();toast="Config saved";toastUntil=System.currentTimeMillis()+1500;}else if(mx>=x+102&&mx<=x+194){ConfigManager.load();toast="Config loaded";toastUntil=System.currentTimeMillis()+1500;}else if(mx>=right-108&&mx<=right){for(Module m:manager.getModules())if(m.isEnabled())m.disable();ConfigManager.save();toast="Modules reset";toastUntil=System.currentTimeMillis()+1500;}}}
        super.mouseClicked(mx,my,btn);
    }
    @Override public void handleMouseInput() throws java.io.IOException{super.handleMouseInput();int dw=org.lwjgl.input.Mouse.getDWheel();if(dw>0)scroll=Math.max(0,scroll-20);else if(dw<0)scroll=Math.min(500,scroll+20);}
    @Override protected void keyTyped(char c,int key) throws java.io.IOException{if(key==Keyboard.KEY_ESCAPE){mc.displayGuiScreen(null);return;}super.keyTyped(c,key);}
}
