package lockin.client.mixin.impl.entity;

import lockin.client.module.ModuleManager;
import lockin.client.module.impl.movement.Sprint;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.potion.Potion;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(EntityPlayerSP.class)
public abstract class MixinEntityPlayerSP {

    @Inject(method = "onLivingUpdate", at = @At("RETURN"))
    private void lockin$forceSprint(CallbackInfo ci) {
        Sprint sprint = ModuleManager.sprint;
        if (sprint == null || !sprint.isEnabled()) {
            return;
        }

        EntityPlayerSP player = (EntityPlayerSP) (Object) this;
        if (player.isSneaking() || player.isPotionActive(Potion.blindness)) {
            return;
        }

        boolean moving = player.movementInput.moveForward != 0.0F
                || player.movementInput.moveStrafe != 0.0F;
        if (!moving) {
            return;
        }

        boolean force = (sprint.allowWhileUsingItem() && player.isUsingItem())
                || (sprint.allowWhileBackwards() && player.movementInput.moveForward < 0.0F)
                || (sprint.allowWhileSideways()
                    && player.movementInput.moveForward == 0.0F
                    && player.movementInput.moveStrafe != 0.0F);

        if (force && !player.isSprinting()) {
            player.setSprinting(true);
        }
    }
}
