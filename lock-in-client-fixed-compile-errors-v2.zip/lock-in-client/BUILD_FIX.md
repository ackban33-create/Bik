# Build fix

The project had three compiler messages in `MixinEntityPlayerSP.java` and one real compiler error in `SliderSetting.java`.

## Fixed errors

### `SliderSetting.java`
The constructor

```java
SliderSetting(String name, double def, double min, double max, double interval)
```

called `this(null, ...)`. Because there are two six-argument constructors whose second parameter is either `String` or `GroupSetting`, Java could not resolve the `null` overload.

It now explicitly selects the `GroupSetting` overload:

```java
this((GroupSetting) null, name, def, min, max, interval);
```

### `MixinEntityPlayerSP.java`
The mixin used `@Shadow` for methods inherited from parent classes (`isSprinting`, `isUsingItem`, and `isPotionActive`). The Mixin annotation processor reported these as missing targets.

The hook now casts `this` to the actual `EntityPlayerSP` target and calls its inherited methods directly. This removes the invalid `@Shadow` declarations while preserving the sprint behavior.

## Project-property fix

The Gradle Kotlin DSL declarations for `baseGroup`, `mcVersion`, and `modid` are already present in `build.gradle.kts`, and the corresponding values are in `gradle.properties`.

## Verification

The two modified Java files were compiled against minimal Java 8-compatible stubs to verify constructor overload resolution and Java syntax/type correctness. A full Forge/Gradle build could not be run in this environment because the Gradle distribution and Forge dependencies are not locally cached and network access is unavailable.
