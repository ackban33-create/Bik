package lockin.client.config;

import com.google.gson.*;
import lockin.client.module.Module;
import lockin.client.module.ModuleManager;
import lockin.client.module.setting.Setting;
import lockin.client.module.setting.impl.*;
import net.minecraft.client.Minecraft;
import java.io.*;

public final class ConfigManager {
    private static boolean dirty;
    private ConfigManager(){}
    public static void markDirty(){dirty=true;}
    private static File file(){return new File(Minecraft.getMinecraft().mcDataDir,"lockin-client/config.json");}
    public static void save(){
        JsonObject root=new JsonObject(); root.addProperty("client","Lock In Client"); root.addProperty("version","1.0");
        JsonObject mods=new JsonObject();
        for(Module m: LockInModulesHolder.manager().getModules()){
            JsonObject o=new JsonObject(); o.addProperty("enabled",m.isEnabled()); o.addProperty("key",m.getKeycode());
            for(Setting s:m.getSettings()) putSetting(o,s);
            mods.add(m.getName(),o);
        }
        root.add("modules",mods);
        File f=file(); if(!f.getParentFile().exists())f.getParentFile().mkdirs();
        try(Writer w=new OutputStreamWriter(new FileOutputStream(f),"UTF-8")){new GsonBuilder().setPrettyPrinting().create().toJson(root,w);dirty=false;}catch(IOException e){e.printStackTrace();}
    }
    public static void load(){File f=file();if(!f.isFile())return;try(Reader r=new InputStreamReader(new FileInputStream(f),"UTF-8")){JsonObject root=new JsonParser().parse(r).getAsJsonObject();JsonObject mods=root.has("modules")?root.getAsJsonObject("modules"):new JsonObject();for(Module m:LockInModulesHolder.manager().getModules()){if(!mods.has(m.getName()))continue;JsonObject o=mods.getAsJsonObject(m.getName());m.setBind(o.has("key")?o.get("key").getAsInt():0);for(Setting s:m.getSettings())s.loadProfile(o);boolean en=o.has("enabled")&&o.get("enabled").getAsBoolean();if(en&&!m.isEnabled())m.enable();else if(!en&&m.isEnabled())m.disable();}dirty=false;}catch(Exception e){e.printStackTrace();}}
    private static void putSetting(JsonObject o,Setting s){
        if(s instanceof ButtonSetting)o.addProperty(s.getProfileKey(),((ButtonSetting)s).isToggled());
        else if(s instanceof SliderSetting)o.addProperty(s.getProfileKey(),((SliderSetting)s).getInput());
        else if(s instanceof KeySetting)o.addProperty(s.getProfileKey(),((KeySetting)s).getKey());
        else if(s instanceof ColorSetting){ColorSetting c=(ColorSetting)s;JsonObject x=new JsonObject();x.addProperty("r",c.getRed());x.addProperty("g",c.getGreen());x.addProperty("b",c.getBlue());x.addProperty("a",c.getAlpha());o.add(s.getProfileKey(),x);}
    }
    public static boolean isDirty(){return dirty;}
    public static final class LockInModulesHolder { public static lockin.client.module.ModuleManager manager(){ return lockin.client.LockInClient.INSTANCE.getModuleManager(); } }
}
