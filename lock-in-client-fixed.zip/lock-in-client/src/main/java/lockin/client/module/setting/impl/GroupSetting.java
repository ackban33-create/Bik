package lockin.client.module.setting.impl;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.List;
import lockin.client.module.setting.Setting;
public class GroupSetting extends Setting {
    private final List<Setting> settings = new ArrayList<>();
    private boolean opened;
    public GroupSetting(String name) { super(name); }
    public List<Setting> getSettings() { return settings; }
    public void addSetting(Setting setting) { settings.add(setting); }
    public boolean isOpened() { return opened; }
    public void setOpened(boolean opened) { this.opened = opened; }
    @Override public void loadProfile(JsonObject data) {}
}
