package lockin.client.module.setting.impl;
import com.google.gson.JsonObject;
import lockin.client.module.setting.Setting;
import java.awt.Color;
public class ColorSetting extends Setting {
    private int r,g,b,a;
    public GroupSetting groupSetting;
    public ColorSetting(String name,int r,int g,int b){this(null,name,r,g,b,255);}
    public ColorSetting(String name,int r,int g,int b,int a){this(null,name,r,g,b,a);}
    public ColorSetting(GroupSetting group,String name,int r,int g,int b){this(group,name,r,g,b,255);}
    public ColorSetting(GroupSetting group,String name,int r,int g,int b,int a){super(name);this.groupSetting=group;this.r=clamp(r);this.g=clamp(g);this.b=clamp(b);this.a=clamp(a);}
    private int clamp(int v){return Math.max(0,Math.min(255,v));}
    public int getRed(){return r;} public int getGreen(){return g;} public int getBlue(){return b;} public int getAlpha(){return a;}
    public void setColor(int r,int g,int b,int a){this.r=clamp(r);this.g=clamp(g);this.b=clamp(b);this.a=clamp(a);} public void setColor(int r,int g,int b){setColor(r,g,b,a);}
    public int getColor(){return (a<<24)|(r<<16)|(g<<8)|b;}
    public float getHue(){return Color.RGBtoHSB(r,g,b,null)[0]*360f;}
    @Override public String getProfileKey(){return groupSetting==null?name:groupSetting.getName()+"."+name;}
    @Override public void loadProfile(JsonObject data){String key=data.has(getProfileKey())?getProfileKey():(data.has(name)?name:null);if(key!=null&&data.get(key).isJsonObject()){JsonObject o=data.getAsJsonObject(key);setColor(o.get("r").getAsInt(),o.get("g").getAsInt(),o.get("b").getAsInt(),o.has("a")?o.get("a").getAsInt():a);}}
}
