package lockin.client.module;

import lockin.client.config.ConfigManager;
import lockin.client.module.setting.Setting;
import lockin.client.module.setting.impl.ButtonSetting;
import net.minecraft.client.Minecraft;
import net.minecraftforge.common.MinecraftForge;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    protected static final Minecraft mc = Minecraft.getMinecraft();
    protected final List<Setting> settings = new ArrayList<>();
    private final String name;
    private final category cat;
    private boolean enabled;
    private int keycode;
    public boolean ignoreOnSave, hidden, closetModule;
    protected Module(String name, category cat){this(name,cat,0);}
    protected Module(String name, category cat, int keycode){this.name=name;this.cat=cat;this.keycode=keycode;}
    public String getName(){return name;} public category moduleCategory(){return cat;} public boolean isEnabled(){return enabled;}
    public int getKeycode(){return keycode;} public void setBind(int key){keycode=key;}
    public List<Setting> getSettings(){return settings;}
    protected void registerSetting(Setting s){settings.add(s);}
    public void enable(){if(enabled)return;enabled=true;MinecraftForge.EVENT_BUS.register(this);onEnable();ConfigManager.markDirty();}
    public void disable(){if(!enabled)return;enabled=false;MinecraftForge.EVENT_BUS.unregister(this);onDisable();ConfigManager.markDirty();}
    public void toggle(){if(enabled)disable();else enable();}
    public void onEnable(){} public void onDisable(){} public void onUpdate(){} public void guiUpdate(){}
    public String getInfo(){return "";}
    public void onKeyBind(){
        if(keycode==0)return;
        boolean down = keycode>=1000 ? Mouse.isButtonDown(keycode-1000) : Keyboard.isKeyDown(keycode);
        if(down){toggle(); try{Thread.sleep(0);}catch(Exception ignored){}}
    }
    public enum category { combat,movement,player,world,render,client }
}
