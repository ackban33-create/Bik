package lockin.client.module.impl.player;

import lockin.client.mixin.impl.accessor.IAccessorEntityLivingBase;
import lockin.client.mixin.impl.accessor.IAccessorMinecraft;
import lockin.client.module.Module;
import lockin.client.module.setting.impl.ButtonSetting;
import lockin.client.utility.Utils;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class DelayRemover extends Module {
    public ButtonSetting oldReg, removeJumpTicks;

    public DelayRemover() {
        super("Delay Remover", category.player, 0);
        this.registerSetting(oldReg = new ButtonSetting("1.7 hitreg", true));
        this.registerSetting(removeJumpTicks = new ButtonSetting("Remove jump ticks", false));
        this.closetModule = true;
    }

    @SubscribeEvent
    public void onTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !mc.inGameHasFocus || !Utils.nullCheck()) {
            return;
        }
        if (oldReg.isToggled()) {
            ((IAccessorMinecraft) mc).setLeftClickCounter(0);
        }
        if (removeJumpTicks.isToggled()) {
            ((IAccessorEntityLivingBase) mc.thePlayer).setJumpTicks(0);
        }
    }
}
