package lockin.client.module.setting.impl;
import com.google.gson.JsonObject;
import lockin.client.module.setting.Setting;
public class DescriptionSetting extends Setting {
    public DescriptionSetting(String text) { super(text); }
    public String getDesc() { return name; }
    @Override public void loadProfile(JsonObject data) {}
}
