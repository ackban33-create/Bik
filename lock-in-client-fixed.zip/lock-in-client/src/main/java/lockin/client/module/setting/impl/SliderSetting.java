package lockin.client.module.setting.impl;

import com.google.gson.JsonObject;
import lockin.client.module.setting.Setting;
import java.math.BigDecimal;
import java.math.RoundingMode;

public class SliderSetting extends Setting {
    private double value, min, max, interval;
    private String[] options;
    private final String suffix;
    public boolean isString;
    public GroupSetting groupSetting;
    public SliderSetting(String name, double def, double min, double max, double interval) { this(null,name,def,min,max,interval); }
    public SliderSetting(GroupSetting group, String name, double def, double min, double max, double interval) { super(name); this.groupSetting=group; this.value=def; this.min=min; this.max=max; this.interval=interval; this.suffix=""; }
    public SliderSetting(String name, int def, String[] options) { super(name); this.value=def; this.options=options; this.min=0; this.max=options.length-1; this.interval=1; this.isString=true; this.suffix=""; }
    public SliderSetting(GroupSetting group, String name, int def, String[] options) { this(name,def,options); this.groupSetting=group; }
    private SliderSetting(String name, String suffix, double def, double min, double max, double interval) { super(name); this.value=def; this.min=min; this.max=max; this.interval=interval; this.suffix=suffix; }
    public String[] getOptions() { return options; }
    public String getSuffix() { return suffix; }
    public double getInput() { return roundToInterval(value,4); }
    public double getMin() { return min; }
    public double getMax() { return max; }
    public double setValue(double v) { v=Math.max(min,Math.min(max,v)); if(interval>0) v=Math.round(v/interval)*interval; return value=v; }
    public void setValueRaw(double v) { value=v; }
    public void setValueWithEvent(double v) { setValue(v); }
    @Override public String getProfileKey() { return groupSetting == null ? name : groupSetting.getName()+"."+name; }
    @Override public void loadProfile(JsonObject data) { String key=data.has(getProfileKey())?getProfileKey():(data.has(name)?name:null); if(key!=null&&data.get(key).isJsonPrimitive()) try{setValue(data.get(key).getAsDouble());}catch(Exception ignored){} }
    public static double roundToInterval(double v,int p){ return new BigDecimal(v).setScale(p,RoundingMode.HALF_UP).doubleValue(); }
}
