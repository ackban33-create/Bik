package lockin.client.module.setting;

import com.google.gson.JsonObject;
import lockin.client.module.Module;

public abstract class Setting {
    protected final String name;
    protected boolean visible = true;

    protected Setting(String name) { this.name = name; }
    public String getName() { return name; }
    public boolean isVisible() { return visible; }
    public void setVisible(boolean visible, Module module) { this.visible = visible; }
    public String getProfileKey() { return name; }
    public abstract void loadProfile(JsonObject data);
}
