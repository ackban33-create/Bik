package lockin.client.module;

import lockin.client.module.impl.movement.Sprint;
import lockin.client.module.impl.player.DelayRemover;
import lockin.client.module.impl.render.*;
import java.util.*;

public class ModuleManager {
    public static BlockOverlay blockOverlay;
    public static Freelook freelook;
    public static HitParticles hitParticles;
    public static ItemPhysics itemPhysics;
    public static NoHurtCam noHurtCam;
    public static DelayRemover delayRemover;
    public static Sprint sprint;
    private final List<Module> modules = new ArrayList<>();
    private final Map<String, Module> byName = new HashMap<>();
    public void register(){
        add(blockOverlay=new BlockOverlay());
        add(freelook=new Freelook());
        add(hitParticles=new HitParticles());
        add(itemPhysics=new ItemPhysics());
        add(noHurtCam=new NoHurtCam());
        add(delayRemover=new DelayRemover());
        add(sprint=new Sprint());
    }
    private void add(Module m){modules.add(m);byName.put(m.getName().toLowerCase(Locale.ROOT),m);}
    public List<Module> getModules(){return Collections.unmodifiableList(modules);}
    public Module getModule(Class<? extends Module> type){for(Module m:modules)if(type.isInstance(m))return m;return null;}
    public Module getModule(String name){return byName.get(name.toLowerCase(Locale.ROOT));}
    public void update(){for(Module m:modules)if(m.isEnabled())m.onUpdate();}
}
