package lockin.client.module.setting.impl;

import com.google.gson.JsonObject;
import lockin.client.module.setting.Setting;

public class ButtonSetting extends Setting {
    private boolean enabled;
    private final String[] legacyKeys;
    public GroupSetting group;

    public ButtonSetting(String name, boolean enabled) { this(null, name, enabled); }
    public ButtonSetting(GroupSetting group, String name, boolean enabled) {
        super(name); this.group = group; this.enabled = enabled; this.legacyKeys = new String[0];
    }
    public ButtonSetting(String name, Runnable method) { super(name); this.enabled = false; this.legacyKeys = new String[0]; this.method = method; this.isMethodButton = true; }
    private Runnable method;
    public boolean isMethodButton;
    public boolean isToggled() { return enabled; }
    public void toggle() { if (!isMethodButton) enabled = !enabled; }
    public void setEnabled(boolean value) { enabled = value; }
    public void enable() { enabled = true; }
    public void disable() { enabled = false; }
    public void runMethod() { if (method != null) method.run(); }
    @Override public String getProfileKey() { return group == null ? name : group.getName() + "." + name; }
    @Override public void loadProfile(JsonObject data) {
        String key = data.has(getProfileKey()) ? getProfileKey() : (data.has(name) ? name : null);
        if (key != null && data.get(key).isJsonPrimitive()) {
            try { enabled = data.getAsJsonPrimitive(key).getAsBoolean(); } catch (Exception ignored) {}
        }
    }
}
