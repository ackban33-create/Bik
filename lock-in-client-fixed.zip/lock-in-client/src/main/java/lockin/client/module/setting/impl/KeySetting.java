package lockin.client.module.setting.impl;
import com.google.gson.JsonObject;
import lockin.client.module.setting.Setting;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
public class KeySetting extends Setting {
    private int key;
    public GroupSetting group;
    public KeySetting(String name,int key){super(name);this.key=key;}
    public KeySetting(GroupSetting group,String name,int key){this(name,key);this.group=group;}
    public int getKey(){return key;} public void setKey(int key){this.key=key;}
    public boolean isPressed(){ if(key==0)return false; return key>=1000?Mouse.isButtonDown(key-1000):Keyboard.isKeyDown(key); }
    @Override public String getProfileKey(){return group==null?name:group.getName()+"."+name;}
    @Override public void loadProfile(JsonObject data){String k=data.has(getProfileKey())?getProfileKey():(data.has(name)?name:null);if(k!=null&&data.get(k).isJsonPrimitive())try{key=data.get(k).getAsInt();}catch(Exception ignored){}}
}
