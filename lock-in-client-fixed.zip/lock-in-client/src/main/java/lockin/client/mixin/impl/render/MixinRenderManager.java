package lockin.client.mixin.impl.render;
import lockin.client.module.ModuleManager;
import lockin.client.module.impl.render.Freelook;
import net.minecraft.client.renderer.entity.RenderManager;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
@Mixin(RenderManager.class)
public class MixinRenderManager {
 @Shadow private float playerViewX; @Shadow private float playerViewY;
 @Redirect(method="cacheActiveRenderInfo",at=@At(value="FIELD",target="Lnet/minecraft/client/renderer/entity/RenderManager;playerViewX:F",opcode=Opcodes.PUTFIELD)) private void lockin$viewX(RenderManager rm,float value){playerViewX=active()?Freelook.cameraPitch:value;}
 @Redirect(method="cacheActiveRenderInfo",at=@At(value="FIELD",target="Lnet/minecraft/client/renderer/entity/RenderManager;playerViewY:F",opcode=Opcodes.PUTFIELD)) private void lockin$viewY(RenderManager rm,float value){playerViewY=active()?Freelook.cameraYaw:value;}
 private boolean active(){return ModuleManager.freelook!=null&&ModuleManager.freelook.isEnabled()&&Freelook.perspectiveToggled;}
}
