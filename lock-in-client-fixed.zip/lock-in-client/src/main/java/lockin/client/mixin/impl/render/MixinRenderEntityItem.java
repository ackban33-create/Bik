package lockin.client.mixin.impl.render;
import lockin.client.module.impl.render.ItemPhysics;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderEntityItem;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.client.resources.model.IBakedModel;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraftforge.client.ForgeHooksClient;
import org.lwjgl.opengl.GL11;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import java.util.Random;
@Mixin(RenderEntityItem.class)
public abstract class MixinRenderEntityItem extends Render<Entity>{
 @Unique private static final Random r=new Random(); @Unique private static long last=System.nanoTime(); @Unique private static double rotation;
 protected MixinRenderEntityItem(RenderManager rm){super(rm);}
 @Inject(method="doRender(Lnet/minecraft/entity/item/EntityItem;DDDFF)V",at=@At("HEAD"),cancellable=true)
 private void lockin$render(EntityItem e,double x,double y,double z,float yaw,float pt,CallbackInfo ci){
  if(ItemPhysics.instance==null||!ItemPhysics.instance.isEnabled())return; ci.cancel(); Minecraft mc=Minecraft.getMinecraft(); RenderEntityItem self=(RenderEntityItem)(Object)this;
  double speed=ItemPhysics.instance.rotationSpeed.getInput(); rotation=(System.nanoTime()-last)/2500000.0*speed; if(!mc.isGamePaused())last=System.nanoTime(); else rotation=0;
  ItemStack stack=e.getEntityItem(); if(stack==null||stack.getItem()==null)return; int seed=Item.getIdFromItem(stack.getItem())+stack.getMetadata(); r.setSeed(seed);
  self.bindTexture(TextureMap.locationBlocksTexture); self.getRenderManager().renderEngine.getTexture(TextureMap.locationBlocksTexture).setBlurMipmap(false,false);
  GlStateManager.enableRescaleNormal(); GlStateManager.alphaFunc(516,0.1f); GlStateManager.enableBlend(); GlStateManager.tryBlendFuncSeparate(770,771,1,0); GlStateManager.pushMatrix();
  IBakedModel model=mc.getRenderItem().getItemModelMesher().getItemModel(stack); boolean is3D=model.isGui3d(); int count=count(stack); GlStateManager.translate((float)x,(float)y,(float)z); if(is3D)GlStateManager.scale(.5f,.5f,.5f); GL11.glRotatef(90,1,0,0); GL11.glRotatef(e.rotationYaw,0,0,1); if(is3D)GlStateManager.translate(0,0,-.08);else GlStateManager.translate(0,0,-.04); if(!e.onGround){e.rotationPitch+=(float)(rotation*2);} else if(!is3D)e.rotationPitch=0; if(is3D||mc.getRenderManager().options!=null)GlStateManager.rotate(e.rotationPitch,1,0,0); GlStateManager.color(1,1,1,1);
  for(int k=0;k<count;k++){GlStateManager.pushMatrix();model=ForgeHooksClient.handleCameraTransforms(model,ItemCameraTransforms.TransformType.GROUND);if(is3D&&k>0){float ox=(r.nextFloat()*2-1)*.15f,oy=(r.nextFloat()*2-1)*.15f,oz=(r.nextFloat()*2-1)*.15f;GlStateManager.translate(self.shouldSpreadItems()?ox:0, self.shouldSpreadItems()?oy:0,oz);}mc.getRenderItem().renderItem(stack,model);GlStateManager.popMatrix();if(!is3D)GlStateManager.translate(0,0,.05375f);}
  GlStateManager.popMatrix();GlStateManager.disableRescaleNormal();GlStateManager.disableBlend(); self.bindTexture(TextureMap.locationBlocksTexture); self.getRenderManager().renderEngine.getTexture(TextureMap.locationBlocksTexture).restoreLastBlurMipmap();
 }
 @Unique private static int count(ItemStack s){if(s.stackSize>48)return 5;if(s.stackSize>32)return 4;if(s.stackSize>16)return 3;if(s.stackSize>1)return 2;return 1;}
}
