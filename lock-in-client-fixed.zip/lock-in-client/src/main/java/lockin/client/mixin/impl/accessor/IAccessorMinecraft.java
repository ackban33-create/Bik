package lockin.client.mixin.impl.accessor;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
@Mixin(Minecraft.class)
public interface IAccessorMinecraft { @Accessor("leftClickCounter") void setLeftClickCounter(int delay); }
