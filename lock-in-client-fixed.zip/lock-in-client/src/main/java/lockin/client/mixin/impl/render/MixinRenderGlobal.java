package lockin.client.mixin.impl.render;
import lockin.client.module.ModuleManager;
import lockin.client.module.impl.render.Freelook;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;
import org.lwjgl.util.vector.Vector3f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
@Mixin(RenderGlobal.class)
public class MixinRenderGlobal {
 @Shadow @Final private Minecraft mc;
 @Unique private boolean active(){return ModuleManager.freelook!=null&&ModuleManager.freelook.isEnabled()&&Freelook.perspectiveToggled;}
 @Redirect(method="setupTerrain",at=@At(value="FIELD",target="Lnet/minecraft/entity/Entity;rotationPitch:F")) private float lockin$pitch(Entity e){return e==mc.getRenderViewEntity()&&active()?Freelook.cameraPitch:e.rotationPitch;}
 @Redirect(method="setupTerrain",at=@At(value="FIELD",target="Lnet/minecraft/entity/Entity;rotationYaw:F")) private float lockin$yaw(Entity e){return e==mc.getRenderViewEntity()&&active()?Freelook.cameraYaw:e.rotationYaw;}
 @Redirect(method="setupTerrain",at=@At(value="INVOKE",target="Lnet/minecraft/client/renderer/RenderGlobal;getViewVector(Lnet/minecraft/entity/Entity;D)Lorg/lwjgl/util/vector/Vector3f;")) private Vector3f lockin$view(RenderGlobal rg,Entity e,double partial){float pitch,yaw;if(e==mc.getRenderViewEntity()&&active()){pitch=Freelook.cameraPitch;yaw=Freelook.cameraYaw;}else{pitch=(float)(e.prevRotationPitch+(e.rotationPitch-e.prevRotationPitch)*partial);yaw=(float)(e.prevRotationYaw+(e.rotationYaw-e.prevRotationYaw)*partial);}if(mc.gameSettings.thirdPersonView==2)pitch+=180f;float cy=MathHelper.cos(-yaw*0.017453292F-(float)Math.PI);float sy=MathHelper.sin(-yaw*0.017453292F-(float)Math.PI);float cp=-MathHelper.cos(-pitch*0.017453292F);float sp=MathHelper.sin(-pitch*0.017453292F);return new Vector3f(sy*cp,sp,cy*cp);}
}
