package lockin.client.mixin.impl.entity;
import lockin.client.module.ModuleManager;
import lockin.client.module.impl.movement.Sprint;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.potion.Potion;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(EntityPlayerSP.class)
public abstract class MixinEntityPlayerSP {
    @Shadow public net.minecraft.util.MovementInput movementInput;
    @Shadow protected net.minecraft.client.Minecraft mc;
    @Shadow public abstract boolean isSneaking();
    @Shadow public abstract boolean isSprinting();
    @Shadow public abstract boolean isUsingItem();
    @Shadow public abstract void setSprinting(boolean sprinting);
    @Inject(method="onLivingUpdate", at=@At("RETURN"))
    private void lockin$forceSprint(CallbackInfo ci){
        Sprint s=ModuleManager.sprint; if(s==null||!s.isEnabled())return;
        if(isSneaking()||isPotionActive(Potion.blindness))return;
        boolean moving=movementInput.moveForward!=0||movementInput.moveStrafe!=0;
        if(!moving)return;
        boolean force=(s.allowWhileUsingItem()&&isUsingItem())||(s.allowWhileBackwards()&&movementInput.moveForward<0)||(s.allowWhileSideways()&&movementInput.moveForward==0&&movementInput.moveStrafe!=0);
        if(force&&!isSprinting())setSprinting(true);
    }
    @Shadow public abstract boolean isPotionActive(Potion potion);
}
