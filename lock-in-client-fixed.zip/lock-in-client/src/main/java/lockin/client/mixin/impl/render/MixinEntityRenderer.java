package lockin.client.mixin.impl.render;
import lockin.client.module.ModuleManager;
import lockin.client.module.impl.render.Freelook;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.EntityRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.util.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
@Mixin(EntityRenderer.class)
public class MixinEntityRenderer {
 @Redirect(method="hurtCameraEffect",at=@At(value="INVOKE",target="Lnet/minecraft/client/renderer/GlStateManager;rotate(FFFF)V")) public void lockin$hurt(float angle,float x,float y,float z){if(ModuleManager.noHurtCam!=null&&ModuleManager.noHurtCam.isEnabled())angle=(float)(angle/14.0*ModuleManager.noHurtCam.multiplier.getInput());GlStateManager.rotate(angle,x,y,z);}
 @Redirect(method="orientCamera",at=@At(value="FIELD",target="Lnet/minecraft/entity/Entity;rotationYaw:F")) private float lockin$yaw(Entity e){return active()?Freelook.cameraYaw:e.rotationYaw;}
 @Redirect(method="orientCamera",at=@At(value="FIELD",target="Lnet/minecraft/entity/Entity;prevRotationYaw:F")) private float lockin$pyaw(Entity e){return active()?Freelook.cameraYaw:e.prevRotationYaw;}
 @Redirect(method="orientCamera",at=@At(value="FIELD",target="Lnet/minecraft/entity/Entity;rotationPitch:F")) private float lockin$pitch(Entity e){return active()?Freelook.cameraPitch:e.rotationPitch;}
 @Redirect(method="orientCamera",at=@At(value="FIELD",target="Lnet/minecraft/entity/Entity;prevRotationPitch:F")) private float lockin$ppitch(Entity e){return active()?Freelook.cameraPitch:e.prevRotationPitch;}
 @Redirect(method="updateCameraAndRender",at=@At(value="FIELD",target="Lnet/minecraft/client/Minecraft;inGameHasFocus:Z")) private boolean lockin$mouse(Minecraft mc){return Freelook.overrideMouse(mc);}
 private boolean active(){return ModuleManager.freelook!=null&&ModuleManager.freelook.isEnabled()&&Freelook.perspectiveToggled;}
}
