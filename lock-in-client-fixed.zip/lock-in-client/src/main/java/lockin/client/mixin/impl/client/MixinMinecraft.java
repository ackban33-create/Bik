package lockin.client.mixin.impl.client;
import lockin.client.module.ModuleManager;
import lockin.client.module.impl.render.Freelook;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.GameSettings;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
@Mixin(Minecraft.class)
public class MixinMinecraft {
 @Redirect(method="runTick",at=@At(value="FIELD",target="Lnet/minecraft/client/settings/GameSettings;thirdPersonView:I",opcode=Opcodes.PUTFIELD))
 private void lockin$thirdPerson(GameSettings settings,int value){if(ModuleManager.freelook!=null&&Freelook.perspectiveToggled)ModuleManager.freelook.resetPerspective();else settings.thirdPersonView=value;}
}
