package lockin.client.mixin.impl.accessor;
import net.minecraft.util.MouseHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
@Mixin(MouseHelper.class)
public interface IAccessorMouseHelper { @Accessor("deltaX") int getDeltaX(); @Accessor("deltaY") int getDeltaY(); }
