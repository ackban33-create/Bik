package lockin.client.mixin.impl.render;
import lockin.client.module.ModuleManager;
import lockin.client.module.impl.render.Freelook;
import net.minecraft.client.renderer.ActiveRenderInfo;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
@Mixin(ActiveRenderInfo.class)
public class MixinActiveRenderInfo {
 @Redirect(method="updateRenderInfo",at=@At(value="FIELD",target="Lnet/minecraft/entity/Entity;rotationYaw:F")) private static float lockin$yaw(Entity entity){return active(entity)?Freelook.cameraYaw:entity.rotationYaw;}
 @Redirect(method="updateRenderInfo",at=@At(value="FIELD",target="Lnet/minecraft/entity/Entity;rotationPitch:F")) private static float lockin$pitch(Entity entity){return active(entity)?Freelook.cameraPitch:entity.rotationPitch;}
 private static boolean active(Entity e){return ModuleManager.freelook!=null&&ModuleManager.freelook.isEnabled()&&Freelook.perspectiveToggled&&e instanceof EntityPlayer;}
}
