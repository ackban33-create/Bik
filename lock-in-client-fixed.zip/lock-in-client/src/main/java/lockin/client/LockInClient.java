package lockin.client;

import lockin.client.config.ConfigManager;
import lockin.client.gui.LockInGui;
import lockin.client.module.ModuleManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.client.ClientCommandHandler;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

@Mod(modid="lockinclient", name="Lock In Client", version="1.0", acceptedMinecraftVersions="[1.8.9]")
public class LockInClient {
    @Mod.Instance
    public static LockInClient INSTANCE;
    public static final Minecraft MC = Minecraft.getMinecraft();
    public static KeyBinding openGui;
    private final ModuleManager moduleManager = new ModuleManager();
    public ModuleManager getModuleManager(){return moduleManager;}
    @Mod.EventHandler
    public void init(FMLInitializationEvent event){
        moduleManager.register();
        openGui=new KeyBinding("Open Lock In GUI", Keyboard.KEY_RSHIFT, "Lock In Client");
        ClientRegistry.registerKeyBinding(openGui);
        MinecraftForge.EVENT_BUS.register(this);
        ConfigManager.load();
    }
    @SubscribeEvent public void onKey(InputEvent.KeyInputEvent e){if(openGui!=null&&openGui.isPressed())MC.displayGuiScreen(new LockInGui());}
    @SubscribeEvent public void onTick(TickEvent.ClientTickEvent e){if(e.phase==TickEvent.Phase.END && MC.thePlayer!=null){for(lockin.client.module.Module m:moduleManager.getModules())m.guiUpdate();moduleManager.update();}}
}
