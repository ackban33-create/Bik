package lockin.client.utility;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
public final class BlockUtils {
    private BlockUtils() {}
    public static AxisAlignedBB getBlockSelectionBox(BlockPos pos){
        Minecraft mc=Minecraft.getMinecraft(); if(mc.theWorld==null||pos==null)return null;
        IBlockState state=mc.theWorld.getBlockState(pos); Block block=state.getBlock();
        block.setBlockBoundsBasedOnState(mc.theWorld,pos); AxisAlignedBB box=block.getSelectedBoundingBox(mc.theWorld,pos);
        return box!=null?box:new AxisAlignedBB(pos.getX(),pos.getY(),pos.getZ(),pos.getX()+1,pos.getY()+1,pos.getZ()+1);
    }
}
