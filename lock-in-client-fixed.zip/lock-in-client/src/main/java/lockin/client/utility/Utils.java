package lockin.client.utility;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
public final class Utils {
    private Utils() {}
    public static boolean nullCheck(){ Minecraft mc=Minecraft.getMinecraft(); return mc!=null && mc.theWorld!=null && mc.thePlayer!=null; }
    public static int mergeAlpha(int color,int alpha){return (color&0x00ffffff)|((alpha&0xff)<<24);}
    public static int getChroma(long speed){long period=Math.max(1L,10000L/Math.max(1L,speed)); float hue=(System.currentTimeMillis()%period)/(float)period; return java.awt.Color.HSBtoRGB(hue,1f,1f);}
}
