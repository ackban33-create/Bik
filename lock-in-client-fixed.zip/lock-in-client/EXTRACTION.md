# Lock In Client extraction notes

The seven module implementations in this project are taken from the user-provided Raven bS release `raven-bs-release-16.1.zip`.

Extracted modules:
- `BlockOverlay` -> custom package `lockin.client.module.impl.render`
- `Freelook` -> same logic, with the Raven-only Freecam guard removed because Freecam is intentionally not part of the extracted client
- `HitParticles` -> same implementation
- `ItemPhysics` -> same implementation
- `NoHurtCam` -> same implementation
- `DelayRemover` -> same implementation
- `Sprint` -> same implementation; extracted client supplies a focused Mixin hook for Raven's sprint-specific behavior

Only focused dependencies are retained: module/settings framework, rendering utilities, config manager, custom GUI, and the Mixin accessors/hooks required by the seven modules.
