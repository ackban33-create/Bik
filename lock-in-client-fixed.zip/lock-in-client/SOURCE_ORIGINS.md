# Source origin manifest

Original archive: `raven-bs-release-16.1.zip`

- `BlockOverlay.java` — `src/main/java/keystrokesmod/module/impl/render/BlockOverlay.java` — SHA-256 `5370a871f17478aa68418b32f60a31caeeca921f56252534fe12973997349cd8`
- `Freelook.java` — `src/main/java/keystrokesmod/module/impl/render/Freelook.java` — SHA-256 `7e27a0f88a34acca0fec4fb20d45a81843822465b3e85538a4ab7a08f9458039`
- `HitParticles.java` — `src/main/java/keystrokesmod/module/impl/render/HitParticles.java` — SHA-256 `e23339927b5a8297f84b4144ab4640c58f18d966f4b524f4fa442636219adb49`
- `ItemPhysics.java` — `src/main/java/keystrokesmod/module/impl/render/ItemPhysics.java` — SHA-256 `391d5ba72cd02c0ce7e90d25f98fab78957df9a817640dd3b52fb467830af260`
- `NoHurtCam.java` — `src/main/java/keystrokesmod/module/impl/render/NoHurtCam.java` — SHA-256 `99432ae49c1f41df2ac25c7b6a56b3de3642d8e291ca5be3e3010d50e1d86425`
- `DelayRemover.java` — `src/main/java/keystrokesmod/module/impl/player/DelayRemover.java` — SHA-256 `6bcdb388a9ac07c97a5fcc64597d2c64601152df5c35a28f24b9d2e4ec187cd9`
- `Sprint.java` — `src/main/java/keystrokesmod/module/impl/movement/Sprint.java` — SHA-256 `fd6dd54dc9524ecc245d984509587793553e6a5938b77dea3349ee8c62c13426`
