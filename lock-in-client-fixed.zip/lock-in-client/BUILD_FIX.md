# Build fix

The Codespaces error in the screenshot came from missing Gradle Kotlin DSL project-property declarations for `baseGroup`, `mcVersion`, and `modid`.

`build.gradle.kts` now declares:

- `val baseGroup: String by project`
- `val mcVersion: String by project`
- `val modid: String by project`

and uses the same property wiring as the original Raven build script.

The local environment does not contain Gradle 8.8 or the Gradle wrapper JAR, so a real Forge dependency resolution/build could not be executed here. In Codespaces, regenerate the wrapper and build with the requested commands.
