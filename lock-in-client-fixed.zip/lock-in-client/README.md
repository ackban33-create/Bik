# Lock In Client

Minecraft Forge 1.8.9 focused client built from the user-provided Raven bS source. Only these seven Raven modules are included:

- Block Overlay
- Free Look
- Hit Particles
- Item Physics
- NoHurtCam
- Delay Remover
- Sprint

The client adds a custom Lock In GUI, JSON config save/load, and a Right Shift GUI keybind.

## Codespaces build

```bash
sdk install java 17.0.12-tem
sdk default java 17.0.12-tem
java -version

wget https://services.gradle.org/distributions/gradle-8.8-bin.zip
unzip -q gradle-8.8-bin.zip
./gradle-8.8/bin/gradle wrapper --gradle-version 8.8
./gradlew build
```

## Notes

The module implementations were extracted from the supplied Raven bS release. Dependencies that only existed for unrelated Raven modules were replaced with focused Lock In equivalents.
