# Raven Lite — Forge 1.8.9

این پروژه عمداً فقط **۷ ماژول در سورس** دارد:

- Block Overlay
- Free Look
- Hit Particles
- Item Physics
- NoHurtCam
- No Hit Delay
- Sprint

GUI نیز از نو برای همین نسخه نوشته شده و هیچ ماژول دیگری در ModuleManager ثبت نمی‌شود.

## GitHub Codespaces

```bash
sdk install java 17.0.12-tem
sdk default java 17.0.12-tem
java -version

unzip -q gradle-8.8-bin.zip
./gradle-8.8/bin/gradle wrapper --gradle-version 8.8
./gradlew build
```

خروجی:

```text
build/libs/ravenlite-1.0.0.jar
```

با `RSHIFT` رابط Raven Lite باز می‌شود و با کلیک روی هر کارت، همان ماژول روشن/خاموش می‌شود.
