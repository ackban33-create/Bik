package keystrokesmod.utility;

import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import org.lwjgl.opengl.GL11;
import java.awt.Color;

public final class Utils {
    private static final Minecraft mc = Minecraft.getMinecraft();
    private Utils() {}

    public static boolean nullCheck() {
        return mc.theWorld != null && mc.thePlayer != null;
    }

    public static int mergeAlpha(int rgb, int alpha) {
        return (alpha << 24) | (rgb & 0x00FFFFFF);
    }

    public static int getChroma(long offset) { return getChroma(offset, 1500L); }

    public static int getChroma(long offset, long speed) {
        float h = ((System.currentTimeMillis() + offset) % Math.max(1L, speed)) / (float)Math.max(1L, speed);
        return Color.HSBtoRGB(h, 0.65f, 1.0f) | 0xFF000000;
    }

    public static AxisAlignedBB getBlockSelectionBox(BlockPos pos, IBlockState state) {
        return state.getBlock().getSelectedBoundingBox(mc.theWorld, pos);
    }

    public static void drawStairs(AxisAlignedBB box, int color, float width) {
        Color c = new Color(color, true);
        GlStateManager.pushMatrix();
        GlStateManager.disableTexture2D();
        GlStateManager.disableDepth();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GL11.glLineWidth(width);
        GL11.glColor4f(c.getRed()/255f,c.getGreen()/255f,c.getBlue()/255f,c.getAlpha()/255f);
        GL11.glBegin(GL11.GL_LINE_STRIP);
        double x=box.minX,y=box.minY,z=box.minZ,X=box.maxX,Y=box.maxY,Z=box.maxZ;
        double[][] pts={{x,y,z},{X,y,z},{X,y,Z},{x,y,Z},{x,y,z},{x,Y,z},{X,Y,z},{X,Y,Z},{x,Y,Z},{x,Y,z}};
        for(double[] p:pts) GL11.glVertex3d(p[0],p[1],p[2]);
        GL11.glEnd();
        GL11.glBegin(GL11.GL_LINES);
        GL11.glVertex3d(X,y,z);GL11.glVertex3d(X,Y,z);
        GL11.glVertex3d(X,y,Z);GL11.glVertex3d(X,Y,Z);
        GL11.glVertex3d(x,y,Z);GL11.glVertex3d(x,Y,Z);
        GL11.glEnd();
        GlStateManager.enableDepth();
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GlStateManager.popMatrix();
    }
}
