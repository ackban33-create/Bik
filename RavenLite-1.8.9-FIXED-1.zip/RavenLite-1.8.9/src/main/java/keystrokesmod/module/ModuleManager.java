package keystrokesmod.module;

import keystrokesmod.module.impl.movement.Sprint;
import keystrokesmod.module.impl.player.DelayRemover;
import keystrokesmod.module.impl.render.BlockOverlay;
import keystrokesmod.module.impl.render.Freelook;
import keystrokesmod.module.impl.render.HitParticles;
import keystrokesmod.module.impl.render.ItemPhysics;
import keystrokesmod.module.impl.render.NoHurtCam;
import java.util.*;

public class ModuleManager {
    public static final List<Module> modules = new ArrayList<>();
    public static final List<Module> organizedModules = new ArrayList<>();
    private static final Map<String,Module> byName = new HashMap<>();
    public static Sprint sprint;
    public static Freelook freelook;
    public static NoHurtCam noHurtCam;

    public void register() {
        addModule(sprint = new Sprint());
        addModule(new DelayRemover());
        addModule(new BlockOverlay());
        addModule(freelook = new Freelook());
        addModule(new HitParticles());
        addModule(new ItemPhysics());
        addModule(noHurtCam = new NoHurtCam());
        modules.sort(Comparator.comparing(Module::getName));
    }
    public void addModule(Module m){modules.add(m);byName.put(m.getName().toLowerCase(),m);}
    public List<Module> getModules(){return modules;}
    public List<Module> inCategory(Module.category c){
        List<Module> r=new ArrayList<>();
        for(Module m:modules) if(m.moduleCategory()==c) r.add(m);
        return r;
    }
    public static Module getModule(String n){return byName.get(n.toLowerCase());}
    public static Module getModule(Class<?> c){
        for(Module m:modules) if(m.getClass()==c) return m; return null;
    }
    public static void sort(){}
}
