package keystrokesmod.module.setting.impl;
import keystrokesmod.module.setting.Setting;
public class DescriptionSetting extends Setting { public DescriptionSetting(String n){super(n);} }
