package keystrokesmod.module.setting.impl;
import keystrokesmod.module.setting.Setting;
import java.awt.Color;
public class ColorSetting extends Setting {
 private int r,g,b,a; public GroupSetting groupSetting;
 public ColorSetting(String n,int r,int g,int b){this(null,n,r,g,b,255);}
 public ColorSetting(String n,int r,int g,int b,int a){this(null,n,r,g,b,a);}
 public ColorSetting(GroupSetting group,String n,int r,int g,int b){this(group,n,r,g,b,255);}
 public ColorSetting(GroupSetting group,String n,int r,int g,int b,int a){super(n);groupSetting=group;this.r=r;this.g=g;this.b=b;this.a=a;}
 public int getRed(){return r;} public int getGreen(){return g;} public int getBlue(){return b;} public int getAlpha(){return a;}
 public int getColor(){return (a<<24)|(r<<16)|(g<<8)|b;} public int getRGB(){return (r<<16)|(g<<8)|b;}
 public float getHue(){return Color.RGBtoHSB(r,g,b,null)[0]*360f;} public float getSaturation(){return Color.RGBtoHSB(r,g,b,null)[1];} public float getBrightness(){return Color.RGBtoHSB(r,g,b,null)[2];}
}
