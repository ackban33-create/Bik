package keystrokesmod.module.setting.impl;
import keystrokesmod.module.setting.Setting;
public class ButtonSetting extends Setting {
 public GroupSetting group; private boolean toggled; private Runnable method;
 public ButtonSetting(String n,boolean v){super(n);toggled=v;}
 public ButtonSetting(GroupSetting g,String n,boolean v){this(n,v);group=g;}
 public ButtonSetting(String n,Runnable r){super(n);method=r;}
 public boolean isToggled(){return toggled;} public void toggle(){toggled=!toggled;} public void setEnabled(boolean v){toggled=v;} public void enable(){toggled=true;} public void disable(){toggled=false;} public void runMethod(){if(method!=null)method.run();}
}
