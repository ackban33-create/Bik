package keystrokesmod.module.setting;
import keystrokesmod.module.Module;
public abstract class Setting {
    protected String name; protected boolean visible=true;
    public Setting(String name){this.name=name;}
    public String getName(){return name;}
    public void setVisible(boolean v, Module m){visible=v;}
    public boolean isVisible(){return visible;}
}
