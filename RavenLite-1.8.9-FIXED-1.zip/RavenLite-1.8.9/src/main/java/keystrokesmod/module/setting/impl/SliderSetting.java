package keystrokesmod.module.setting.impl;
import keystrokesmod.module.setting.Setting;
public class SliderSetting extends Setting {
 private double value,min,max,step; private String[] options;
 public GroupSetting groupSetting;
 public SliderSetting(String n,double v,double min,double max,double step){this(null,n,v,min,max,step);}
 public SliderSetting(GroupSetting g,String n,double v,double min,double max,double step){super(n);groupSetting=g;value=v;this.min=min;this.max=max;this.step=step;}
 public SliderSetting(String n,int v,String[] opts){this(null,n,v,opts);}
 public SliderSetting(GroupSetting g,String n,int v,String[] opts){super(n);groupSetting=g;value=v;options=opts;min=0;max=opts.length-1;step=1;}
 public double getInput(){return value;} public double setValue(double v){value=Math.max(min,Math.min(max,v));return value;}
 public float getInputFloat(){return (float)value;} public double getMin(){return min;} public double getMax(){return max;} public String[] getOptions(){return options;}
}
