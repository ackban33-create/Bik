package keystrokesmod.module.setting.impl;
import keystrokesmod.module.setting.Setting;
public class GroupSetting extends Setting { private boolean opened; public GroupSetting(String n){super(n);} public boolean isOpened(){return opened;} public void setOpened(boolean b){opened=b;} }
