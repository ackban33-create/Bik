package keystrokesmod.module.setting.impl;
import keystrokesmod.module.setting.Setting;
import org.lwjgl.input.Keyboard;
public class KeySetting extends Setting {
 private int key;
 public KeySetting(String n,int k){super(n);key=k;}
 public boolean isPressed(){return key!=0 && Keyboard.isKeyDown(key);}
 public int getKey(){return key;}
 public void setKey(int k){key=k;}
}
