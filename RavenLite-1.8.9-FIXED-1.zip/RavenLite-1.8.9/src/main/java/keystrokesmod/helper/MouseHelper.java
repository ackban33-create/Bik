package keystrokesmod.helper;
import net.minecraftforge.client.event.MouseEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Mouse;
public class MouseHelper {
 private static int wheel; private static boolean cached;
 public static void updateWheelCache(){wheel=Mouse.getDWheel();cached=true;}
 public static void clearWheelCache(){cached=false;wheel=0;}
 public static boolean isScrollDown(int key){if(!cached)updateWheelCache();return key==1069?wheel>0:key==1070&&wheel<0;}
 @SubscribeEvent public void onMouse(MouseEvent e){}
}
