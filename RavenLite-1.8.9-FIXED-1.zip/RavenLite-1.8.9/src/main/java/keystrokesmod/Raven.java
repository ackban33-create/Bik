package keystrokesmod;

import keystrokesmod.gui.LiteClickGui;
import keystrokesmod.helper.MouseHelper;
import keystrokesmod.module.Module;
import keystrokesmod.module.ModuleManager;
import net.minecraft.client.Minecraft;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

@Mod(modid="ravenlite", name="Raven Lite", version="1.0.0", acceptedMinecraftVersions="[1.8.9]")
public class Raven {
    public static final Minecraft mc=Minecraft.getMinecraft();
    public static ModuleManager moduleManager;
    private static boolean guiDown;
    @Mod.EventHandler
    public void init(FMLInitializationEvent e){
        moduleManager=new ModuleManager();
        moduleManager.register();
        MinecraftForge.EVENT_BUS.register(this);
        MinecraftForge.EVENT_BUS.register(new MouseHelper());
    }
    @SubscribeEvent
    public void tick(TickEvent.ClientTickEvent e){
        if(e.phase!=TickEvent.Phase.END)return;
        MouseHelper.updateWheelCache();
        for(Module m:moduleManager.getModules()){
            if(mc.currentScreen==null)m.onKeyBind(); else m.syncKeyBindState();
            if(m.isEnabled())m.onUpdate();
        }
        boolean down=Keyboard.isKeyDown(Keyboard.KEY_RSHIFT);
        if(down && !guiDown && mc.currentScreen==null)mc.displayGuiScreen(new LiteClickGui());
        guiDown=down;
        MouseHelper.clearWheelCache();
    }
    public static ModuleManager getModuleManager(){return moduleManager;}
}
