package keystrokesmod.mixin.impl.render;
import keystrokesmod.module.ModuleManager;
import keystrokesmod.module.impl.render.Freelook;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;
import org.lwjgl.util.vector.Vector3f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
@Mixin(RenderGlobal.class)
public class MixinRenderGlobal {
 @Shadow private Minecraft mc;
 private boolean active(){return ModuleManager.freelook!=null&&ModuleManager.freelook.isEnabled()&&Freelook.perspectiveToggled;}
 @Redirect(method="setupTerrain",at=@At(value="FIELD",target="Lnet/minecraft/entity/Entity;rotationPitch:F"))
 private float pitch(Entity e){return e==mc.getRenderViewEntity()&&active()?Freelook.cameraPitch:e.rotationPitch;}
 @Redirect(method="setupTerrain",at=@At(value="FIELD",target="Lnet/minecraft/entity/Entity;rotationYaw:F"))
 private float yaw(Entity e){return e==mc.getRenderViewEntity()&&active()?Freelook.cameraYaw:e.rotationYaw;}
 @Redirect(method="setupTerrain",at=@At(value="INVOKE",target="Lnet/minecraft/client/renderer/RenderGlobal;getViewVector(Lnet/minecraft/entity/Entity;D)Lorg/lwjgl/util/vector/Vector3f;"))
 private Vector3f vector(RenderGlobal rg,Entity e,double pt){
  float p=e.prevRotationPitch+(e.rotationPitch-e.prevRotationPitch)*(float)pt;
  float y=e.prevRotationYaw+(e.rotationYaw-e.prevRotationYaw)*(float)pt;
  if(e==mc.getRenderViewEntity()&&active()){p=Freelook.cameraPitch;y=Freelook.cameraYaw;}
  if(mc.gameSettings.thirdPersonView==2)p+=180;
  float cy=MathHelper.cos(-y*0.017453292F-(float)Math.PI),sy=MathHelper.sin(-y*0.017453292F-(float)Math.PI);
  float cp=-MathHelper.cos(-p*0.017453292F),sp=MathHelper.sin(-p*0.017453292F);
  return new Vector3f(sy*cp,sp,cy*cp);
 }
}
