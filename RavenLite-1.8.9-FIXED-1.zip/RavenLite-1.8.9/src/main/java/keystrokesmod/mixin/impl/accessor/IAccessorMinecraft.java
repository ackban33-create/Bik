package keystrokesmod.mixin.impl.accessor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import net.minecraft.client.Minecraft;
@Mixin(Minecraft.class)
public interface IAccessorMinecraft {
 @Accessor("leftClickCounter") void setLeftClickCounter(int value);
}
