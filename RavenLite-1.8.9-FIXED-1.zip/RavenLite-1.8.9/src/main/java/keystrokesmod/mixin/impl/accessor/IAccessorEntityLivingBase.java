package keystrokesmod.mixin.impl.accessor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import net.minecraft.entity.EntityLivingBase;
@Mixin(EntityLivingBase.class)
public interface IAccessorEntityLivingBase {
 @Accessor("jumpTicks") void setJumpTicks(int value);
}
