package keystrokesmod.mixin.impl.render;
import keystrokesmod.module.ModuleManager;
import keystrokesmod.module.impl.render.Freelook;
import net.minecraft.client.renderer.ActiveRenderInfo;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
@Mixin(ActiveRenderInfo.class)
public class MixinActiveRenderInfo {
 @Redirect(method="updateRenderInfo",at=@At(value="FIELD",target="Lnet/minecraft/entity/Entity;rotationYaw:F"))
 private static float yaw(Entity e){return ModuleManager.freelook!=null&&ModuleManager.freelook.isEnabled()&&Freelook.perspectiveToggled&&e instanceof EntityPlayer?Freelook.cameraYaw:e.rotationYaw;}
 @Redirect(method="updateRenderInfo",at=@At(value="FIELD",target="Lnet/minecraft/entity/Entity;rotationPitch:F"))
 private static float pitch(Entity e){return ModuleManager.freelook!=null&&ModuleManager.freelook.isEnabled()&&Freelook.perspectiveToggled&&e instanceof EntityPlayer?Freelook.cameraPitch:e.rotationPitch;}
}
