package keystrokesmod.mixin.impl.render;
import keystrokesmod.module.ModuleManager;
import keystrokesmod.module.impl.render.Freelook;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.EntityRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.client.renderer.GlStateManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
@Mixin(EntityRenderer.class)
public class MixinEntityRenderer {
 private boolean active(){return ModuleManager.freelook!=null&&ModuleManager.freelook.isEnabled()&&Freelook.perspectiveToggled;}
 @Redirect(method="hurtCameraEffect",at=@At(value="INVOKE",target="Lnet/minecraft/client/renderer/GlStateManager;rotate(FFFF)V"))
 private void hurt(float angle,float x,float y,float z){if(ModuleManager.noHurtCam!=null&&ModuleManager.noHurtCam.isEnabled())angle=(float)(angle/14*ModuleManager.noHurtCam.multiplier.getInput());GlStateManager.rotate(angle,x,y,z);}
 @Redirect(method="orientCamera",at=@At(value="FIELD",target="Lnet/minecraft/entity/Entity;rotationYaw:F"))
 private float yaw(Entity e){return active()?Freelook.cameraYaw:e.rotationYaw;}
 @Redirect(method="orientCamera",at=@At(value="FIELD",target="Lnet/minecraft/entity/Entity;prevRotationYaw:F"))
 private float pyaw(Entity e){return active()?Freelook.cameraYaw:e.prevRotationYaw;}
 @Redirect(method="orientCamera",at=@At(value="FIELD",target="Lnet/minecraft/entity/Entity;rotationPitch:F"))
 private float pitch(Entity e){return active()?Freelook.cameraPitch:e.rotationPitch;}
 @Redirect(method="orientCamera",at=@At(value="FIELD",target="Lnet/minecraft/entity/Entity;prevRotationPitch:F"))
 private float ppitch(Entity e){return active()?Freelook.cameraPitch:e.prevRotationPitch;}
 @Redirect(method="updateCameraAndRender",at=@At(value="FIELD",target="Lnet/minecraft/client/Minecraft;inGameHasFocus:Z"))
 private boolean mouse(Minecraft mc){return Freelook.overrideMouse(mc);}
}
