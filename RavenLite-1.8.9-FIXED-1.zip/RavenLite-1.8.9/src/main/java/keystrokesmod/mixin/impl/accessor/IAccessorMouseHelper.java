package keystrokesmod.mixin.impl.accessor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import net.minecraft.util.MouseHelper;
@Mixin(MouseHelper.class)
public interface IAccessorMouseHelper {
 @Accessor("deltaX") int getDeltaX();
 @Accessor("deltaY") int getDeltaY();
}
