package keystrokesmod.mixin.impl.render;
import keystrokesmod.module.ModuleManager;
import keystrokesmod.module.impl.render.Freelook;
import net.minecraft.client.renderer.entity.RenderManager;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
@Mixin(RenderManager.class)
public class MixinRenderManager {
 @Shadow private float playerViewX; @Shadow private float playerViewY;
 @Redirect(method="cacheActiveRenderInfo",at=@At(value="FIELD",target="Lnet/minecraft/client/renderer/entity/RenderManager;playerViewX:F",opcode=Opcodes.PUTFIELD))
 private void x(RenderManager r,float v){playerViewX=active()?Freelook.cameraPitch:v;}
 @Redirect(method="cacheActiveRenderInfo",at=@At(value="FIELD",target="Lnet/minecraft/client/renderer/entity/RenderManager;playerViewY:F",opcode=Opcodes.PUTFIELD))
 private void y(RenderManager r,float v){playerViewY=active()?Freelook.cameraYaw:v;}
 private boolean active(){return ModuleManager.freelook!=null&&ModuleManager.freelook.isEnabled()&&Freelook.perspectiveToggled;}
}
