package keystrokesmod.gui;

import keystrokesmod.Raven;
import keystrokesmod.module.Module;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.input.Mouse;
import org.lwjgl.input.Keyboard;
import java.io.IOException;
import java.util.List;

public class LiteClickGui extends GuiScreen {
    private final int panelW=620, panelH=390;
    private int left, top;
    private int scroll=0;

    @Override public void initGui(){
        ScaledResolution sr=new ScaledResolution(mc);
        left=(sr.getScaledWidth()-panelW)/2; top=(sr.getScaledHeight()-panelH)/2;
    }

    @Override public void drawScreen(int mouseX,int mouseY,float partialTicks){
        drawRect(0,0,width,height,0xB9101118);
        drawRect(left,top,left+panelW,top+panelH,0xFF171A24);
        drawRect(left,top,left+5,top+panelH,0xFF7C5CFF);
        drawString(fontRendererObj,"RAVEN LITE",left+28,top+22,0xFFFFFFFF);
        drawString(fontRendererObj,"7 MODULES  •  FORGE 1.8.9",left+28,top+39,0xFF8F96A8);

        List<Module> ms=Raven.moduleManager.getModules();
        int y=top+70+scroll;
        for(Module m:ms){
            int h=38;
            boolean hover=mouseX>=left+20&&mouseX<=left+panelW-20&&mouseY>=y&&mouseY<=y+h;
            int bg=m.isEnabled()?0xFF25233A:(hover?0xFF20232E:0xFF1D2029);
            drawRect(left+20,y,left+panelW-20,y+h,bg);
            drawRect(left+20,y,left+24,y+h,m.isEnabled()?0xFF8B6CFF:0xFF343947);
            drawString(fontRendererObj,m.getName(),left+34,y+9,m.isEnabled()?0xFFFFFFFF:0xFFCFD3DD);
            String cat=m.moduleCategory().name().toUpperCase();
            drawString(fontRendererObj,cat,left+34,y+23,0xFF777F92);
            drawString(fontRendererObj,m.isEnabled()?"ON":"OFF",left+panelW-62,y+13,m.isEnabled()?0xFF9B82FF:0xFF666D7E);
            y+=48;
        }
        drawString(fontRendererObj,"RSHIFT  close/open",left+20,top+panelH-24,0xFF72798B);
        drawString(fontRendererObj,"Click a module to toggle it",left+panelW-185,top+panelH-24,0xFF72798B);
        super.drawScreen(mouseX,mouseY,partialTicks);
    }

    @Override protected void mouseClicked(int mouseX,int mouseY,int mouseButton)throws IOException{
        if(mouseButton==0){
            int y=top+70+scroll;
            for(Module m:Raven.moduleManager.getModules()){
                if(mouseX>=left+20&&mouseX<=left+panelW-20&&mouseY>=y&&mouseY<=y+38){m.toggle();return;}
                y+=48;
            }
        }
        super.mouseClicked(mouseX,mouseY,mouseButton);
    }
    @Override protected void keyTyped(char typedChar,int keyCode)throws IOException{
        if(keyCode==Keyboard.KEY_ESCAPE || keyCode==Keyboard.KEY_RSHIFT){mc.displayGuiScreen(null);return;}
        super.keyTyped(typedChar,keyCode);
    }
    @Override public void handleMouseInput()throws IOException{
        int d=Mouse.getEventDWheel();
        if(d!=0){scroll+=d>0?20:-20;scroll=Math.max(-150,Math.min(0,scroll));}
        super.handleMouseInput();
    }
}
